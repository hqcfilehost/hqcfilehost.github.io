# MapleMono-NF-CN-VF

## Font Files

- [MapleMono-NF-CN-Italic[wght].ttf](./MapleMono-NF-CN-Italic%5Bwght%5D.ttf)
- [MapleMono-NF-CN[wght].ttf](./MapleMono-NF-CN%5Bwght%5D.ttf)
