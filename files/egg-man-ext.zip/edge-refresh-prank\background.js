// 刷新惊喜 — 后台 Service Worker
//
// 触发逻辑（访问 OR 刷新任意网站）：
//   1. 只看主 frame 的导航（排除 iframe）；
//   2. 只对真实网站（http / https）生效，避开浏览器内部页、扩展自身页；
//   3. 每次“访问或刷新”掷一次骰子，命中概率 1/1997 时，
//      把当前标签页跳转到本地 redirect.html（显示 image.gif + 自动播放 bgm.mp3）；
//   4. 用扩展自身页面白名单，避免死循环。

const CHANCE = 1 / 100;       // 命中概率，改这里即可调整（1/50、1/500……）

// 我们自己扩展的页面地址前缀，防止递归触发
const MY_ORIGIN_PREFIX = chrome.runtime.getURL('');

chrome.webNavigation.onCommitted.addListener((details) => {
  // 只看最外层 frame
  if (details.frameId !== 0) return;

  const url = details.url;

  // 只对真实网站（http/https）生效，过滤 about:、chrome://、edge:// 等
  if (!/^https?:\/\//i.test(url)) return;

  // 排除扩展自身页面
  if (url.startsWith(MY_ORIGIN_PREFIX)) return;

  // 掷骰子
  if (Math.random() < CHANCE) {
    // 把当前标签页跳转到惊喜页
    chrome.tabs.update(details.tabId, {
      url: chrome.runtime.getURL('redirect.html')
    });
  }
});
