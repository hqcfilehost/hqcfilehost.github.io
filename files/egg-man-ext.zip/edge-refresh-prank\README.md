# EGG ROOM

Edge / Chromium 扩展：**访问或刷新任意网页时，有 1/100 概率自动跳转到一个动图并播放背景音乐。**

## 目录结构

```
edge-refresh-prank/
├── manifest.json      # MV3 清单
├── background.js      # 后台：检测访问/刷新、掷骰子、跳转
├── redirect.html      # 惊喜页（显示图片 + 播放 BGM）
├── image.gif          # ⬅ 需要你手动放入的动图（格式为 GIF）
├── bgm.mp3            # ⬅ 需要你手动放入的背景音乐
├── icons/
│   └── icon*.png      # 扩展图标（占位，替换为树图片）
└── README.md
```

## 你需要手动添加的文件

1. 把那张红紫色像素树动图保存为 `image.gif`，放进本文件夹。
2. 把背景音乐保存为 `bgm.mp3`，放进本文件夹。
   - 若用的是其他格式（如 .ogg / .wav），请同步修改 `redirect.html` 里的
     `<audio src="bgm.mp3">` 文件名。
3. 要把图标换成那棵树：把树的**静态 PNG**（建议 128×128）重命名为 `icon128.png`，
   放进 `icons/` 文件夹，覆盖占位图标即可（16/32/48 会自动缩放，也可一并替换）。

## 安装到 Edge

1. 在地址栏打开 `edge://extensions`。
2. 打开左下角/右侧的 **开发人员模式 (Developer mode)**。
3. 点击 **加载解压缩的扩展 (Load unpacked)**。
4. 选择本文件夹 `edge-refresh-prank`。
5. 完成。去任意网页按 `F5` 刷新即可测试（概率较低，多刷几次）。

## 调整概率

打开 `background.js`，修改顶部的常量即可：

```js
const CHANCE = 1 / 100;   // 改成 1/50、1/500 都行
```

改完在 `edge://extensions` 里点一下扩展卡片上的 **重新加载** 图标。

## 说明

- 只在 **访问或刷新** 网页（http/https 主页面）时触发；走 iframe / 浏览器内部页（chrome://、edge://）不会触发。
- 每次访问或刷新都会独立掷一次骰子，长期概率约为 1/1997。
- 跳转到我们自己的页面，所以不会死循环。
- 仅供娱乐 / Demo 用途。
